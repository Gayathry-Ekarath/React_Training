function multi_table(n, i = 1) {
  if (i == 11) return;
  console.log(n + " * " + i + " = " + n * i);
  i++;
  multi_table(n, i);
}
let n = 5;
console.log("Multiplication Table of 5");
multi_table(n);
